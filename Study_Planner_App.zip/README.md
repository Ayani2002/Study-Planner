# Study Planner Web App

A modern group project for managing studies with features like:
- Weekly Planner
- Daily Tasks
- Subject Tracker
- Timer / Focus Mode
- Notes Section
- Progress Overview
- Contact & Feedback

## Team Members
- S/21/454 → Home Page
- S/21/403 → About Page
- S/21/525 → User Guide
- S/21/336 → Weekly Planner
- S/21/332 → Daily Tasks
- S/21/433 → Subject Tracker
- S/21/334 → Timer/Focus Mode
- S/21/533 → Notes Section
- S/21/124 → Progress Overview
- S/21/382 → Contact/Feedback

## How to Run
1. Clone the repo
2. Open `index.html` in your browser
3. Or visit GitHub Pages link after deployment
